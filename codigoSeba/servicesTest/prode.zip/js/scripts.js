var groupsCallback = function (response) {
    console.log(response);
};

var _initScript = function () {
    var services = new ProdeServicesTEST();
    services.getGroups(0, groupsCallback);
};

document.addEventListener("DOMContentLoaded", _initScript);